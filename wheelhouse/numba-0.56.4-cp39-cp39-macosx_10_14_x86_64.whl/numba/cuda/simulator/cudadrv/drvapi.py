'''
drvapi is not implemented in the simulator, but this module exists to allow
tests to import correctly.
'''
